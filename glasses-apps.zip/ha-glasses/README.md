# Glasses apps for Meta Ray-Ban Display

Six small web apps (plain HTML/JS, no build step, 600x600, D-pad: arrows / Enter / Esc) plus two helper scripts.

| App | What it does | Needs |
|---|---|---|
| `apps/home-remote` | Blinds (open/close/±25%), lights, switches, scenes through Home Assistant | HA reachable over **https** from your phone |
| `apps/chimera` | Robot HUD: battery, mode, temps, Sit/Stand/Walk, head-follow, E-STOP (Esc always sends STOP) | A robot service implementing `GET /status`, `POST /cmd` (see header of `apps/chimera/index.html`); `tools/mock_robot.py` is a stand-in |
| `apps/homelab` | ComfyUI queue + GPU VRAM, NAS CPU/RAM/volumes/disk temp | `tools/homelab_status.py` running on your network |
| `apps/smarttalk` | Hands-free: say "start smart talk"; listens and shows 2-3 reply options (plus a quick fact) as the other person finishes each point; "stop smart talk" wipes the transcript | `tools/talk_proxy.py` with your Anthropic key; browser speech recognition on the glasses is **unverified**; check recording-consent laws |
| `apps/look` | Captures a camera frame and shows an info card for buildings, objects, plants, signs and text (never identifies people) | `tools/look_proxy.py` with your Anthropic key; glasses camera access from a web app is **unverified** |
| `apps/viewtube` | YouTube search (voice or recents) and in-lens player | Free YouTube Data API v3 key |

Every app has a `?demo` mode that needs nothing, e.g. `apps/chimera/?demo`.

## Install on the glasses
1. Meta AI app → Settings → App Info → tap *App version* 5 times → enable Developer Mode.
2. Host this folder at a public HTTPS URL. Easiest: push to a GitHub repo → Settings → Pages → deploy from `main`.
3. Meta AI app → App connections → Web apps → Add a web app → name + `https://<you>.github.io/<repo>/` (the launcher).

## Pair each app (secrets stay on your device, never in the repo)
Open the app URL once with a hash; it saves the values to local storage and strips the hash. Add `&reset=1` to clear.

- Home Remote: `apps/home-remote/#url=https://your-ha.example&token=LONG_LIVED_TOKEN&domains=cover,light,switch,scene`
  - Create a **dedicated Home Assistant user** for the token. In `configuration.yaml` allow the Pages origin:
    `http: { cors_allowed_origins: ["https://<you>.github.io"] }`
- Chimera: `apps/chimera/#url=https://robot.example&token=OPTIONAL`
- Home Lab: `apps/homelab/#url=https://homelab.example`
- Smart Talk: `apps/smarttalk/#url=https://talk.example&token=TALK_TOKEN&lang=en-US&about=short+info+about+you` (lang e.g. `it-IT`)
- Look: `apps/look/#url=https://look.example&token=LOOK_TOKEN`
- ViewTube: `apps/viewtube/#key=YOUR_YOUTUBE_API_KEY` (restrict the key to your Pages origin)

Pages served over https cannot call plain `http://` addresses (mixed content). Put robot/aggregator/HA behind HTTPS, e.g. `tailscale serve`.

## Helper scripts
- `ANTHROPIC_API_KEY=... TALK_TOKEN=... python3 tools/talk_proxy.py 8101` — Smart Talk backend (`MOCK=1` for canned answers).
- `ANTHROPIC_API_KEY=... LOOK_TOKEN=... python3 tools/look_proxy.py 8100` — Look backend (`MOCK=1` for a canned answer).
- `python3 tools/mock_robot.py 8080` — mock Chimera for testing the HUD.
- `COMFY_URL=http://127.0.0.1:8188 DSM_URL=https://nas:5001 DSM_USER=... DSM_PASS=... python3 tools/homelab_status.py 8099`

## Tested vs not tested
Tested headlessly (Chrome, 600x600): D-pad navigation, every demo mode, Home Remote service logic in demo, Chimera live against the mock robot (commands + E-STOP), Home Lab live against a mock ComfyUI.
**Not tested** (no hardware/accounts here): the real Claude call in `look_proxy.py` and camera access on the glasses (Look was tested with a fake camera and a mock proxy; Smart Talk with a scripted fake speech recognizer and a mock proxy), the real Claude calls in `talk_proxy.py`, real speech recognition on the glasses, real Home Assistant, real glasses, DSM calls in `homelab_status.py`, YouTube search + iframe seek/pause, voice search, head-follow orientation. Expect small fixes when you first run them.
