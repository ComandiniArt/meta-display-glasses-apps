/* Shared helpers for Meta Ray-Ban Display web apps (no dependencies).
   window.Glass = { cfg(key, defaults), toast(msg), nav(root, {onEnter, onBack}), el(html) } */
(() => {
'use strict';

/* Per-app config kept in localStorage on the phone/glasses only (never committed to the repo).
   Pair once by opening  <app>/index.html#key=value&key2=value2  — values are saved and the hash is stripped.
   Add  &reset=1  to clear.  Add  ?demo  to the query string to force demo mode. */
function cfg(storageKey, defaults = {}) {
  let c = {};
  try { c = JSON.parse(localStorage.getItem(storageKey) || '{}'); } catch {}
  if (location.hash.length > 1) {
    const p = new URLSearchParams(location.hash.slice(1));
    if (p.get('reset')) { c = {}; try { localStorage.removeItem(storageKey); } catch {} }
    else {
      for (const [k, v] of p) c[k] = v;
      try { localStorage.setItem(storageKey, JSON.stringify(c)); } catch {}
    }
    history.replaceState(null, '', location.pathname + location.search);
  }
  const out = Object.assign({}, defaults, c);
  out.demo = new URLSearchParams(location.search).has('demo');
  return out;
}

let toastT;
function toast(msg, ms = 1800) {
  const t = document.getElementById('toast'); if (!t) return;
  t.textContent = msg; t.style.display = 'block';
  clearTimeout(toastT); toastT = setTimeout(() => t.style.display = 'none', ms);
}

function el(html) { const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }

/* D-pad spatial navigation. getRoot() returns the element whose [tabindex="0"] children are focusable.
   Arrow keys move to the nearest target in that direction, Enter activates, Escape/Backspace = back. */
function nav({ getRoot, onEnter, onBack, onKey }) {
  function focusables() { return [...getRoot().querySelectorAll('[tabindex="0"]')]; }
  function move(dir) {
    const els = focusables(); if (!els.length) return;
    const cur = els.includes(document.activeElement) ? document.activeElement : null;
    if (!cur) { els[0].focus(); return; }
    const a = cur.getBoundingClientRect(), ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    const vert = dir === 'ArrowUp' || dir === 'ArrowDown';
    let best = null, bestScore = Infinity;
    for (const e of els) {
      if (e === cur) continue;
      const b = e.getBoundingClientRect(), dx = b.left + b.width / 2 - ax, dy = b.top + b.height / 2 - ay;
      const ok = dir === 'ArrowUp' ? dy < -4 : dir === 'ArrowDown' ? dy > 4 : dir === 'ArrowLeft' ? dx < -4 : dx > 4;
      if (!ok) continue;
      const score = (vert ? Math.abs(dy) : Math.abs(dx)) + (vert ? Math.abs(dx) : Math.abs(dy)) * 3;
      if (score < bestScore) { bestScore = score; best = e; }
    }
    if (best) { best.focus(); best.scrollIntoView({ block:'nearest' }); }
  }
  document.addEventListener('keydown', e => {
    if (onKey && onKey(e) === true) { e.preventDefault(); return; }
    if (e.key.startsWith('Arrow')) { e.preventDefault(); move(e.key); }
    else if (e.key === 'Enter') { e.preventDefault(); const f = document.activeElement; if (f && f.matches('[tabindex="0"]')) onEnter && onEnter(f); }
    else if (e.key === 'Escape' || e.key === 'Backspace') { e.preventDefault(); onBack && onBack(); }
  });
  document.addEventListener('click', e => {           // tap/click: phone preview + desktop debugging
    const t = e.target.closest('[tabindex="0"]'); if (!t) return; t.focus(); onEnter && onEnter(t);
  });
}

window.Glass = { cfg, toast, nav, el };
})();
