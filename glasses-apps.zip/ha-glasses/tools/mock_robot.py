#!/usr/bin/env python3
"""Mock Chimera robot implementing the HUD contract (GET /status, POST /cmd) with CORS.
Run:  python3 tools/mock_robot.py 8080     then open apps/chimera/index.html#url=http://localhost:8080
Replace with the real ESP32-S3 / Jetson service later; the HUD only needs these two routes."""
import json, sys, time
from http.server import BaseHTTPRequestHandler, HTTPServer

T0 = time.time()
S = {"battery": 77, "mode": "idle", "temp_c": 40, "rssi": -55, "estop": False,
     "servos": [{"name": n, "temp_c": 42 + i, "ok": True} for i, n in enumerate(["FL", "FR", "RL", "RR", "Neck"])]}
LOG = []

class H(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    def _json(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code); self._cors(); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self): self.send_response(204); self._cors(); self.end_headers()
    def do_GET(self):
        if self.path == "/status": self._json({**S, "uptime_s": int(time.time() - T0)})
        elif self.path == "/log": self._json(LOG)
        else: self._json({"error": "not found"}, 404)
    def do_POST(self):
        if self.path != "/cmd": return self._json({"error": "not found"}, 404)
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        c = body.get("cmd"); LOG.append(body)
        if c in ("sit", "stand", "walk"): S["mode"], S["estop"] = c, False
        elif c == "stop": S["mode"] = "idle"
        elif c == "estop": S["mode"], S["estop"] = "estop", True
        elif c in ("wag", "look"): pass
        else: return self._json({"error": "unknown cmd"}, 400)
        self._json({"ok": True})
    def log_message(self, *a): pass

if __name__ == "__main__":
    HTTPServer(("0.0.0.0", int(sys.argv[1]) if len(sys.argv) > 1 else 8080), H).serve_forever()
