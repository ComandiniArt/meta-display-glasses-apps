#!/usr/bin/env python3
"""Look proxy: receives a camera frame from the glasses app, asks Claude what it shows, returns a short card.
The Anthropic API key stays here on the server, never in the web app.

  ANTHROPIC_API_KEY=sk-ant-... LOOK_TOKEN=some-shared-secret python3 tools/look_proxy.py 8100
  MOCK=1 python3 tools/look_proxy.py 8100      # canned answer, no API call (for testing)

POST /look  {"image": "<base64 jpeg>", "hint": "optional"}  ->  {"title": "...", "lines": ["...", "..."]}
Expose over HTTPS (e.g. `tailscale serve`) and pair the app with  apps/look/#url=https://...&token=LOOK_TOKEN
The API call below follows the standard Messages API shape and has NOT been run against the live API from this sandbox."""
import json, os, sys, urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

MODEL = os.environ.get("LOOK_MODEL", "claude-sonnet-5-5")
KEY = os.environ.get("ANTHROPIC_API_KEY", "")
TOKEN = os.environ.get("LOOK_TOKEN", "")
MOCK = os.environ.get("MOCK") == "1"
SYSTEM = ("You are the info card on smart glasses. Look at the photo and say what the wearer is looking at: a building, "
          "landmark, artwork, object, plant, animal, product, sign or text. Reply with a short title on the first line, then at most "
          "3 very short facts (under 12 words each), one per line, no bullets or markdown. Translate foreign text. "
          "If people are visible, never identify anyone or guess who they are; you may mention that people are present or read a visible name tag. "
          "If unsure, say what you can see and that you are unsure.")

def ask(image_b64, hint):
    if MOCK:
        return "Sample: brick apartment building\nPre-war style, about 6 floors\nGround-floor cafe with green awning\n(mock answer, no API call)"
    body = {"model": MODEL, "max_tokens": 250, "system": SYSTEM, "messages": [{"role": "user", "content": [
        {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": image_b64}},
        {"type": "text", "text": hint or "What am I looking at?"}]}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(), method="POST",
        headers={"x-api-key": KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)["content"][0]["text"]

class H(BaseHTTPRequestHandler):
    def _c(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
    def _j(self, o, code=200):
        b = json.dumps(o).encode(); self.send_response(code); self._c()
        self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self): self.send_response(204); self._c(); self.end_headers()
    def do_POST(self):
        if self.path != "/look": return self._j({"error": "not found"}, 404)
        if TOKEN and self.headers.get("Authorization") != "Bearer " + TOKEN: return self._j({"error": "unauthorized"}, 401)
        try:
            n = int(self.headers.get("Content-Length", 0))
            if n > 4_000_000: return self._j({"error": "image too large"}, 413)
            d = json.loads(self.rfile.read(n)); text = ask(d["image"], d.get("hint", ""))
            lines = [l.strip() for l in text.strip().splitlines() if l.strip()]
            self._j({"title": lines[0], "lines": lines[1:4]})
        except Exception as e:
            self._j({"error": str(e)[:120]}, 500)
    def log_message(self, *a): pass

if __name__ == "__main__":
    if not MOCK and not KEY: sys.exit("Set ANTHROPIC_API_KEY (or MOCK=1)")
    HTTPServer(("0.0.0.0", int(sys.argv[1]) if len(sys.argv) > 1 else 8100), H).serve_forever()
