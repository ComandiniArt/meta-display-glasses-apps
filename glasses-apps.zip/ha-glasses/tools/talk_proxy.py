#!/usr/bin/env python3
"""Smart Talk proxy: takes the last few lines of a live conversation and returns short reply suggestions.
The Anthropic key stays on this server. Nothing is logged or stored.

  ANTHROPIC_API_KEY=sk-ant-... TALK_TOKEN=shared-secret python3 tools/talk_proxy.py 8101
  MOCK=1 python3 tools/talk_proxy.py 8101      # canned answers (replies only when the last line ends with '?')

POST /suggest {"lines": ["...", ...], "about": "optional info about the wearer"}
  -> {"skip": false, "replies": ["...", "..."], "fact": "..."}   or   {"skip": true}
Uses a small fast model for latency. The API call follows the standard Messages API shape and has NOT been run
against the live API from the sandbox where this was written."""
import json, os, re, sys, urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

MODEL = os.environ.get("TALK_MODEL", "claude-haiku-5-5")
KEY = os.environ.get("ANTHROPIC_API_KEY", "")
TOKEN = os.environ.get("TALK_TOKEN", "")
MOCK = os.environ.get("MOCK") == "1"
SYSTEM = ("You whisper reply suggestions to a person wearing smart glasses during a live, in-person conversation. "
          "Input: the most recent lines of the conversation (speakers are not labeled, speech-to-text may contain errors) and optional "
          "info about the wearer. Decide whether the other person just said something the wearer should now answer. If not (small talk filler, "
          "the wearer was speaking, unclear), return {\"skip\": true}. Otherwise give 2 or 3 natural options the wearer could say out loud, "
          "each under 14 words, in the language of the conversation, with different stances (for example agree, ask a question back, "
          "politely say you need to check). Never invent facts about the wearer or claim experience they may not have; if an answer needs a "
          "fact you are not sure of, suggest a clarifying question or an honest 'let me get back to you' instead. Optionally add \"fact\": one "
          "short, confident, widely known fact (under 15 words) that helps the wearer, else an empty string. "
          "Reply with JSON only: {\"skip\": false, \"replies\": [...], \"fact\": \"...\"}")

def ask(lines, about):
    if MOCK:
        if lines and lines[-1].rstrip().endswith("?"):
            return {"skip": False, "replies": ["Good question, I think so.", "What made you ask that?", "Let me check and get back to you."], "fact": "Mock fact."}
        return {"skip": True}
    user = ("About the wearer: " + about + "\n" if about else "") + "Conversation so far:\n" + "\n".join(lines[-12:])
    body = {"model": MODEL, "max_tokens": 220, "system": SYSTEM, "messages": [{"role": "user", "content": user}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(), method="POST",
        headers={"x-api-key": KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as r:
        text = json.load(r)["content"][0]["text"]
    m = re.search(r"\{.*\}", text, re.S)
    d = json.loads(m.group(0)) if m else {"skip": True}
    d["replies"] = [str(x)[:120] for x in d.get("replies", [])][:3]
    return d

class H(BaseHTTPRequestHandler):
    def _c(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
    def _j(self, o, code=200):
        b = json.dumps(o).encode(); self.send_response(code); self._c()
        self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self): self.send_response(204); self._c(); self.end_headers()
    def do_POST(self):
        if self.path != "/suggest": return self._j({"error": "not found"}, 404)
        if TOKEN and self.headers.get("Authorization") != "Bearer " + TOKEN: return self._j({"error": "unauthorized"}, 401)
        try:
            n = int(self.headers.get("Content-Length", 0))
            if n > 20000: return self._j({"error": "too large"}, 413)
            d = json.loads(self.rfile.read(n)); self._j(ask(d.get("lines", []), d.get("about", "")))
        except Exception as e:
            self._j({"error": str(e)[:120]}, 500)
    def log_message(self, *a): pass

if __name__ == "__main__":
    if not MOCK and not KEY: sys.exit("Set ANTHROPIC_API_KEY (or MOCK=1)")
    HTTPServer(("0.0.0.0", int(sys.argv[1]) if len(sys.argv) > 1 else 8101), H).serve_forever()
