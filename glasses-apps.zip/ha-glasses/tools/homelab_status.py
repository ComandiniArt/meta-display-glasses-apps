#!/usr/bin/env python3
"""Home Lab status aggregator: polls ComfyUI and a Synology NAS, serves GET /status as JSON with CORS.
Run on any always-on machine on your network, then expose it to your phone over HTTPS (e.g. `tailscale serve`).

  COMFY_URL=http://127.0.0.1:8188  DSM_URL=https://nas.local:5001  DSM_USER=...  DSM_PASS=... \
  python3 tools/homelab_status.py 8099

ComfyUI part uses its stock /queue and /system_stats endpoints.
DSM part (login + SYNO.Core.System.Utilization + SYNO.Storage.CGI.Storage) is written from the public DSM Web API
conventions and has NOT been tested against a real DSM; use a read-only DSM user. Any failure degrades to
{"ok": false, "error": ...} for that section instead of breaking the feed."""
import json, os, ssl, sys, time, urllib.parse, urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

COMFY = os.environ.get("COMFY_URL", "").rstrip("/")
DSM = os.environ.get("DSM_URL", "").rstrip("/")
DSM_USER, DSM_PASS = os.environ.get("DSM_USER", ""), os.environ.get("DSM_PASS", "")
CTX = ssl.create_default_context(); CTX.check_hostname = False; CTX.verify_mode = ssl.CERT_NONE  # NAS self-signed cert (LAN only)

def get_json(url, timeout=4):
    with urllib.request.urlopen(url, timeout=timeout, context=CTX) as r:
        return json.load(r)

def comfy():
    if not COMFY: return {"ok": False, "error": "COMFY_URL not set"}
    try:
        q = get_json(COMFY + "/queue"); s = get_json(COMFY + "/system_stats")
        dev = (s.get("devices") or [{}])[0]
        tot, free = dev.get("vram_total", 0), dev.get("vram_free", 0)
        return {"ok": True, "running": len(q.get("queue_running", [])), "pending": len(q.get("queue_pending", [])),
                "gpu": dev.get("name", "GPU"), "vram_used_pct": round(100 * (tot - free) / tot) if tot else None}
    except Exception as e:
        return {"ok": False, "error": str(e)[:80]}

_sid = {"v": None, "t": 0}
def dsm_sid():
    if _sid["v"] and time.time() - _sid["t"] < 600: return _sid["v"]
    u = DSM + "/webapi/auth.cgi?" + urllib.parse.urlencode({"api": "SYNO.API.Auth", "version": 3, "method": "login",
        "account": DSM_USER, "passwd": DSM_PASS, "session": "Core", "format": "sid"})
    d = get_json(u)
    if not d.get("success"): raise RuntimeError("DSM login failed")
    _sid.update(v=d["data"]["sid"], t=time.time()); return _sid["v"]

def dsm_call(api, method, version=1):
    u = DSM + "/webapi/entry.cgi?" + urllib.parse.urlencode({"api": api, "version": version, "method": method, "_sid": dsm_sid()})
    d = get_json(u)
    if not d.get("success"): raise RuntimeError(f"{api} failed")
    return d["data"]

def nas():
    if not (DSM and DSM_USER): return {"ok": False, "error": "DSM_URL/DSM_USER not set"}
    try:
        u = dsm_call("SYNO.Core.System.Utilization", "get")
        cpu = u.get("cpu", {}); cpu_pct = cpu.get("user_load", 0) + cpu.get("system_load", 0)
        mem_pct = u.get("memory", {}).get("real_usage")
        st = dsm_call("SYNO.Storage.CGI.Storage", "load_info")
        vols = [{"id": v.get("id") or v.get("vol_path"), "status": v.get("status"),
                 "used_pct": round(100 * int(v["size"]["used"]) / int(v["size"]["total"])) if v.get("size") else None}
                for v in st.get("volumes", [])]
        temps = [d.get("temp") for d in st.get("disks", []) if d.get("temp") is not None]
        return {"ok": True, "cpu_pct": cpu_pct, "mem_pct": mem_pct, "volumes": vols, "disk_temp_max": max(temps) if temps else None}
    except Exception as e:
        return {"ok": False, "error": str(e)[:80]}

class H(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204); self._c(); self.end_headers()
    def _c(self):
        self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
    def do_GET(self):
        if self.path != "/status": self.send_response(404); self.end_headers(); return
        b = json.dumps({"ts": int(time.time()), "comfy": comfy(), "nas": nas()}).encode()
        self.send_response(200); self._c(); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def log_message(self, *a): pass

if __name__ == "__main__":
    HTTPServer(("0.0.0.0", int(sys.argv[1]) if len(sys.argv) > 1 else 8099), H).serve_forever()
